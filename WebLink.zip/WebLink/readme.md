Prerequisite: 

Java jdk-1.8 or above is installed in System

maven is installed and configured in system

Steps: 

Copy the project in local and unzip it

Import the same in IDEA (Eclipse/Intellij/Other)

Do a maven update (right click on project->maven->update Maven Projct)

Build a project with maven following cmd to download dependencies :: mvn clean install

To run in parallel , open testng.xml-> right click->run As-> testNG Suite

to run single scenario , open TestRunner-> right click->run As->testNG
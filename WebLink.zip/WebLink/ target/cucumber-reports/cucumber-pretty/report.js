$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/test/java/Features/AddNewUser.feature");
formatter.feature({
  "line": 2,
  "name": "Create a new User from admin Login",
  "description": "",
  "id": "create-a-new-user-from-admin-login",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@feature"
    }
  ]
});
formatter.scenario({
  "line": 5,
  "name": "Create New User",
  "description": "",
  "id": "create-a-new-user-from-admin-login;create-new-user",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 4,
      "name": "@NewUser"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 6,
      "value": "#Login to application as Admi"
    }
  ],
  "line": 7,
  "name": "user login to the \"OrangeHRM\" application in \"Chrome\" browser",
  "keyword": "Given "
});
formatter.step({
  "line": 8,
  "name": "user enters \"userName\" into username element",
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "user enters \"password\" into username element",
  "keyword": "When "
});
formatter.step({
  "line": 10,
  "name": "user clicks on submit button",
  "keyword": "And "
});
formatter.step({
  "line": 11,
  "name": "user validate \"OrangeHRM\" test is visible on Homepage",
  "keyword": "And "
});
formatter.step({
  "line": 12,
  "name": "User closes the browser",
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "OrangeHRM",
      "offset": 19
    },
    {
      "val": "Chrome",
      "offset": 46
    }
  ],
  "location": "LoginApplication.user_login_to_the_application(String,String)"
});
formatter.result({
  "duration": 13999729400,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "userName",
      "offset": 13
    }
  ],
  "location": "LoginApplication.user_enters_into_username_element(String)"
});
formatter.result({
  "duration": 421282600,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "password",
      "offset": 13
    }
  ],
  "location": "LoginApplication.user_enters_into_username_element(String)"
});
formatter.result({
  "duration": 219326400,
  "status": "passed"
});
formatter.match({
  "location": "LoginApplication.submitButton()"
});
formatter.result({
  "duration": 7539788300,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "OrangeHRM",
      "offset": 15
    }
  ],
  "location": "LoginApplication.user_validate_test_is_visible_on_Homepage(String)"
});
formatter.result({
  "duration": 85661500,
  "status": "passed"
});
formatter.match({
  "location": "LoginApplication.closeBrowser()"
});
fformatter.result({
  "duration": 870922100,
  "status": "passed"
});
});